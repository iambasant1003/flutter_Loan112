

import 'main_common.dart';

void main() {
  mainCommon("dev");
}
