

class ConstText {
  // App Name
  static const appName = 'Loan112';

  // font family
  static const fontType = "Manrope";
  static const requestSource = "and";
  static const utilityBillType = "UTILITY BILL";
  static const exceptionError = "Something went wrong...";


}
