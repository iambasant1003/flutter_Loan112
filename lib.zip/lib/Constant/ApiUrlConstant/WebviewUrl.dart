
class Urls {
static const String Uat = "https://uat-api.loan112fintech.com/";
static const String PreProd ="https://preprod-api.vrindafintech.com/";
static const String Prod = "https://api.loan112fintech.com/";
static const String privacy = "https://www.rupee112.com/privacy-policy";
static const String TermAndCondition ="https://www.rupee112.com/terms-and-conditions";
static const String Pay_Url = "https://www.rupee112.com/repay-loan";
static const String FAQ = "https://loan112.com/faq";
}

class UrlsNods {
  static const String Uat = "https://uat-node.loan112fintech.com/journey-service/api/v1/";
  static const String Prod = "https://node-api.loan112fintech.com/journey-service/api/v1/";
  static const String privacy = "https://loan112.com/privacy-policy";
  static const String TermAndCondition ="https://loan112.com/terms-and-conditions";
  static const String Pay_Url = "https://loan112.com/repay-loan";
  static const String FAQ = "https://loan112.com/faq";
}
