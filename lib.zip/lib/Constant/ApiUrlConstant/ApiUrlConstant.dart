


const String andRD= "AAPPS";

const String sendOTPNode = "customer-send-otp";
const String verifyOTPNode = "customer-verify-otp";
const String sendOTPhp = "saveCustomerProfile$andRD";
const String verifyOTPhp = "saveCustomerProfile$andRD";
const String dashBoard = "getDashboardDetails$andRD";
const String getCustomerDetailsPHP = "getCustomerProfile$andRD";
const String uploadSelfie = "upload-selfie";
const String checkEligibility = "journey-create-leads";
const String getPinCodeDetails = "getCityStateByPincode$andRD";
const String customerKyc = "customer-ekyc";
const String customerKycVerification = "eKyc-verification";
const String deleteCustomerProfile = "deleteCustomerProfile$andRD";
const String generateLoanOffer = "journey-generate-loan-offer";
const String uploadDocs = "journey-upload-docs";
const String loanAcceptance = "accept-loan-offer";
const String  loanPurpose = "getMasterLoanPurpose$andRD";
const String getUtilityDoc = "get-current-docs-by-leadId";
const String uploadResidenceDoc = "upload-residence-docs";
const String uploadBankStatement = "journey-upload-docs";
const String addReFeRance ="add-reference";
const String updateBankingDetails = "customer-banking";
const String verifyIfscCode = "getBankDetailsByIfsc$andRD";
const String bankAccountType = "getMasterBankType$andRD";
const String uploadOnlineBankStatement = "whatsapp/journey-upload-docs";
const String checkBankStatementStatus = "account-aggregator-verification";
const String getLoanHistory = "getLoanHistory";
const String initiateCashFreePayment = "initiateCashfreeRequest$andRD";
const String completeCashFreePayment = "completeCashfreePayment$andRD";
const String initiateRazorpayPayment = "initiateRazorRequest$andRD";
const String completeRazorpayPayment = "completeRazorRequest$andRD";
const String calculateDistance = "calculate-distance";
const String bankStatementVerification   = "bank-statement-verifification";




//'https://uat-node.loan112fintech.com/journey-service/api/v1/whatsapp/journey-upload-docs'



// ////api end pont
// const val ANDRD = "AAPPS"
// //    const val ANDRD = ""
// const val Check_Instant_App_Version = "checkInstantAppVersion$ANDRD"
// const val getCustomerProfile = "getCustomerProfileAAPPS"
// const val End_saveCustomerProfile = "saveCustomerProfile$ANDRD"
// const val END_saveleadDetails = "saveleadDetails$ANDRD"
// const val GET_CITY_STATE_BY_PINCODE = "getCityStateByPincode$ANDRD"
// const val GET_MASTER_MARITAL_STATUS = "getMasterMaritalStatus$ANDRD"
// const val GET_MASTER_RESIDENCE_TYPE = "getMasterResidenceType$ANDRD"
// const val GET_MASTER_COMPANY_TYPE = "getMasterCompanyType$ANDRD"
// const val GET_MASTER_BANK_TYPE = "getMasterBankType$ANDRD"
// const val GET_BANK_DETAILS_BY_IFSC = "getBankDetailsByIfsc$ANDRD"
// const val GET_BANK_IFSC_LIST = "getBankIfscList$ANDRD"
// const val GET_MASTER_LOAN_PURPOSE = "getMasterLoanPurpose$ANDRD"
// const val DASHBOARD_DETAILS ="getDashboardDetails$ANDRD"
// const  val PROFILE_DETAILS = "getProfileDetails$ANDRD"
// const  val DELETE_CUSTOMER_RPROFILE=   "deleteCustomerProfile$ANDRD"
// const val  ACCOUNT_AGGREGATOR_INIT= "account_aggregator$ANDRD"
// const val  ACCOUNT_AGGREGATOR_VERIFY= "account_aggregator_verify$ANDRD"
// const val  LOAN_HISTORY   = "getLoanHistory"
// const val PAYMENT_INIT = "initiateRazorRequest$ANDRD"
// const val PAYMENT_COMPLETE ="completeRazorRequest$ANDRD"
// const val EMI_SCHEDULER = "repaymentSchedule$ANDRD"
// const val EMI_HISTORY = "getLoanHistory$ANDRD"
// const val CASH_FREE_INIT = "initiateCashfreeRequest$ANDRD"
// const val CASH_FREE_COMPLETE ="completeCashfreePayment$ANDRD"
//
//
// //    NodJs N means nodJs api
// const val SEND_OTP_N = "customer-send-otp"
// const val VERIFY_OTP_N =  "customer-verify-otp"
// const val CHECK_ELIGIBILITY ="journey-create-leads"
// const val UPLOAD_DOC = "journey-upload-docs"
// const val LOAN_GENERATE = "journey-generate-loan-offer"
// const val LOAN_ACCEPT = "accept-loan-offer"
// const val EKYC_GET_URL = "customer-ekyc"
// const val EKYC_VERIFICATION ="eKyc-verification"
// const val SELFIE_UPLOAD ="upload-selfie"
// const val BANK_DETAILS = "customer-banking"
// const val EMPLOYMENT_DETAILS= "employment-details"
// const val ADD_REFERENCE ="add-reference"
// const val GET_DOC_TYPE_0F_RESIDENCE = "get-current-docs-by-leadId"
// const val UPLOAD_DOC_RESIDENCE = "upload-residence-docs"
// const val AA_VERIFICATION =  "account-aggregator-verification"
// const val GET_LEAD_ID = "get-lead-id"
// const val DIS_CALCULATE = "calculate-distance"

